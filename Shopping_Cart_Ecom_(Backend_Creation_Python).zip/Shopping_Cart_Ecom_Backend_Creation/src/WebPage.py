from flask import Flask, redirect, url_for, render_template, request, session
from datetime import timedelta

app = Flask(__name__)
app.secret_key = 'Shopping'
app.permanent_session_lifetime = timedelta(minutes=5)


# some condition
# a = False


@app.route("/")
def home():
    return "Hello! this is the main page <h1>HELLO<h1>"


@app.route('/admin')
def admin():
    # if a:
    return redirect((url_for('user', name='admin!')))


@app.route('/index')
def html():
    return render_template('demo.html', content='Admin')


@app.route('/list')
def userList():
    return render_template('list.html', content=['Admin', 'Customer', 'Guest'])


@app.route('/htmlDemo')
def htmlDemo():
    return render_template('boot_index.html', content='Admin')


@app.route("/<name>")
def user(name):
    if 'password' in session:
        print(session)
        password = session['password']
        return f'Hello {name}  your pass is {password}'
    else:
        return redirect(url_for('userLogin'))


@app.route('/login', methods=['POST', 'GET'])
def userLogin():
    if request.method == 'POST':
        session.permanent = True
        userName = request.form['username']
        userPass = request.form['password']

        # store userName and userPassword in sessions
        session['username'] = userName
        session['password'] = userPass

        return redirect(url_for("user", name=userName))
    else:
        if 'userName' in session:
            return redirect(url_for("user", name= userName))
        return render_template('loginPage.html')


if __name__ == '__main__':
    app.run(debug=True)
